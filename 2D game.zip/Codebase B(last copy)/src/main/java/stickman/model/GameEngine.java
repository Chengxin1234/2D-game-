package stickman.model;

import stickman.model.Score.Score;
import stickman.model.levels.Level;

import java.io.IOException;

public interface GameEngine {
  Level getCurrentLevel();

  void startLevel();

  // Hero inputs - boolean for success (possibly for sound feedback)
  boolean jump();

  boolean moveLeft();

  boolean moveRight();

  boolean stopMoving();

  long getTimeSinceStart();

  long getHeroHealth();

  void tick() throws IOException;

  /**
   * When a level is restarted we need to clean out the old entity views, this is how we signal to
   * the
   *
   * @return true if the game engine needs the entities refreshed
   */
  boolean needsRefresh();

  /** After a refresh is completed, the clean method must be called to reset the flag */
  void clean();

  String getHeadsUpDisplayMessage();

  void setCurrentLevel(Level currentLevel);

  void setCloneTrigger(Boolean trigger);

  void Save();

  void Load();

  long getLevelScore();

  long getTotalLevelScore();

  long getCurrentTime();

  boolean getHeroIsHere();

  void  setHeroIsHere(boolean heroIsHere);

  boolean isTransitionHappen();

  void setTransitionHappen(boolean transitionHappen);

  boolean isHeroDiedBefore();

  void setHeroDiedBefore(boolean heroDiedBefore);


}
