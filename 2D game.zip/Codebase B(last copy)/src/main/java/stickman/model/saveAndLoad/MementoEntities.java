package stickman.model.saveAndLoad;

import stickman.model.entities.Entity;
import stickman.model.levels.Level;

public class MementoEntities {
    private Entity state;
    public MementoEntities(Entity entity){
        this.state = entity;
    }

    public Entity getEntitiesState(){
        return this.state;
    }
}
