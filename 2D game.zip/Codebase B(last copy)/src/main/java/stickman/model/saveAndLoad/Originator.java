package stickman.model.saveAndLoad;

import stickman.model.entities.Entity;
import stickman.model.levels.Level;

public class Originator {
    private Entity entitystate;
    private Level levelstate;
    private Long storedCurrentTime;
    private Long storedStartTime;

    ////Levelscore
    private Long LevelScore;
    private long totalLevelScore;
    private long slimeScore;
    private long timeScore;
    private long tmp2;
    private long tmp;


    public Originator(Level levelstate, Long storedCurrentTime,Long storedStartTime, Long levelScore,
                      long totalLevelScore, long slimeScore, long timeScore, long tmp2, long tmp) {
        this.levelstate = levelstate;
        this.storedCurrentTime = storedCurrentTime;
        this.storedStartTime = storedStartTime;
        LevelScore = levelScore;
        this.totalLevelScore = totalLevelScore;
        this.slimeScore = slimeScore;
        this.timeScore = timeScore;
        this.tmp2 = tmp2;
        this.tmp = tmp;
    }

    public void setEntitiesState(Entity entity) {
        this.entitystate = entity;
    }



    public void setLevelState(Level levelstate){
        System.out.println( "Current level added!" );
        this.levelstate = levelstate;
    }

    public Level getLevelState(){
        return levelstate;
    }

    public MementoEntities saveToMementoEntities(){
        return new MementoEntities(entitystate);
    }



    public Long getStoredCurrentTime() {
        System.out.println("storedCurrentTime "+ storedCurrentTime);
        return storedCurrentTime;
    }

    public void setStoredCurrentTime(Long storedStartTime) {
        this.storedCurrentTime = storedCurrentTime;
        System.out.println("storedCurrentTime "+ storedCurrentTime);
    }


    public Long getLevelScore() {
        return LevelScore;
    }

    public void setLevelScore(Long levelScore) {
        LevelScore = levelScore;
    }

    public long getTotalLevelScore() {
        return totalLevelScore;
    }

    public void setTotalLevelScore(long totalLevelScore) {
        this.totalLevelScore = totalLevelScore;
    }

    public Level getLevelstate() {
        return levelstate;
    }

    public void setLevelstate(Level levelstate) {
        this.levelstate = levelstate;
    }

    public long getSlimeScore() {
        return slimeScore;
    }

    public void setSlimeScore(long slimeScore) {
        this.slimeScore = slimeScore;
    }

    public long getTimeScore() {
        return timeScore;
    }

    public void setTimeScore(long timeScore) {
        this.timeScore = timeScore;
    }

    public long getTmp2() {
        return tmp2;
    }

    public void setTmp2(long tmp2) {
        this.tmp2 = tmp2;
    }

    public long getTmp() {
        return tmp;
    }

    public void setTmp(long tmp) {
        this.tmp = tmp;
    }

    public Long getStoredStartTime() {
        return storedStartTime;
    }

    public void setStoredStartTime(Long storedStartTime) {
        this.storedStartTime = storedStartTime;
    }
}
