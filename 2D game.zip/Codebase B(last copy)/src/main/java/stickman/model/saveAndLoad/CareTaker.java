package stickman.model.saveAndLoad;

import org.w3c.dom.ls.LSOutput;
import stickman.model.levels.Level;

import java.util.ArrayList;
import java.util.List;

public class CareTaker {

    //Entitiies
    private List<MementoEntities> ml = new ArrayList<>();
    private List<MementoEntities> ml2 = new ArrayList<>();
//    private MementoLevel mementoLevel;

    public void addToMementoEntitiesMl2(MementoEntities MementoEntityState){
        ml2.add(MementoEntityState);
//        System.out.println("Add!");
    }

//
//    public void addToMementoLevel(MementoLevel MementoLevelState){
//        this.mementoLevel = MementoLevelState;
//    }

    public MementoEntities getMementoEntity(int i){
//        System.out.println("Hero saved X position: " + ml.get(i).getEntitiesState().getXPos());
        return ml.get(i);
    }

//    public MementoLevel getMementoLevel(){
//        return mementoLevel;
//    }

    public List<MementoEntities> getMl() {
        return ml;
    }

    public List<MementoEntities> getMl2() {
        return ml2;
    }

    public void push (){
        this.ml = this.ml2;
        this.ml2 = new ArrayList<>();
    }



}
