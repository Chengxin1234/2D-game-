package stickman.model;

import java.io.IOException;
import java.util.List;

import stickman.model.LevelTransition.LevelTransition;
import stickman.model.Score.Score;
import stickman.model.config.ConfigParser;
import stickman.model.entities.Entity;
import stickman.model.entities.MovableEntity;
import stickman.model.entities.StaticEntity;
import stickman.model.entities.character.Hero;
import stickman.model.levels.Level;
import stickman.model.levels.LevelBuilder;

import stickman.model.saveAndLoad.CareTaker;
import stickman.model.saveAndLoad.MementoEntities;
import stickman.model.saveAndLoad.Originator;
import stickman.view.SoundPlayer;

/** An implementation of the Game Engine interface, allows control of the player */
public class GameEngineImpl implements GameEngine {
  private Level currentLevel;
  private ConfigParser config;
  private String headsUpDisplayMessage = "";
  private boolean needsRefresh = false;
  private boolean gameFinished = false;
  private SoundPlayer soundPlayer = new SoundPlayer();
  private long startTime;
  private long endTime;
  private long currentTime;
  private long totalLevelScore;
  private LevelTransition levelTransition = new LevelTransition();
  private boolean levelTrigger = false;
  private CareTaker careTaker = new CareTaker();
  private Originator originator;
  private Score score = new Score(this);
  //if one of the oject is hero
  private boolean heroIsHere;
  private boolean heroDiedBefore;



  public GameEngineImpl(ConfigParser config) {
    this.config = config;

  }


  @Override
  public void setCloneTrigger(Boolean trigger) {
    this.levelTrigger = trigger;
  }


  @Override
  public void Save() {
    //Linked with Keyboard
    System.out.println("save reached");
    //Buildup an Originator
    originator = new Originator(currentLevel,currentTime,startTime,score.getLevelScore(),totalLevelScore,score.getSlimeScore()
    ,score.getTimeScore(),score.getTmp2(),score.getTmp());
    //Save Entity
    careTaker.getMl2().removeAll(careTaker.getMl2());
    for (Entity entity : currentLevel.getEntities()) {
      originator.setEntitiesState(entity.deepClone());
      careTaker.addToMementoEntitiesMl2(originator.saveToMementoEntities());
    }
  }

  public  void deleteAllEntities(){
    currentLevel.getEntities().forEach(Entity::delete);
    currentLevel.getEntities().removeAll(currentLevel.getEntities());
    currentLevel.getDynamicEntities().removeAll(currentLevel.getDynamicEntities());
    currentLevel.getStaticEntities().removeAll( currentLevel.getStaticEntities());
    needsRefresh = true;
  }


  @Override
  public void Load() {
    System.out.println("load reached ");
    //Delete all entites firstly
    deleteAllEntities();
    careTaker.push();

    //Then setting Level value
    setCurrentLevel(originator.getLevelState());

    //Then setting timevalue
      if(isTransitionHappen() || heroDiedBefore){
        System.out.println("Success");
        this.startTime = System.currentTimeMillis() - (originator.getStoredCurrentTime() - currentTime);
        heroDiedBefore = false;
        setTransitionHappen(false);
      }else{
        this.startTime = currentTime - originator.getStoredCurrentTime() + originator.getStoredStartTime();
      }

    //Then Score value
    score.setLevelScore(originator.getLevelScore());
    score.setSlimeScore(originator.getSlimeScore());
    score.setTimeScore(originator.getTimeScore());
    score.setTmp(originator.getTmp());
    score.setTmp2(originator.getTmp2());

    //Replace currentlEVEL USING Stored level
    for (int i = 0; i < careTaker.getMl().size(); i++) {
      if (careTaker.getMementoEntity(i).getEntitiesState() instanceof Hero) {
        currentLevel.replaceHero((Hero) careTaker.getMementoEntity(i).getEntitiesState());
      }
      if (careTaker.getMementoEntity(i).getEntitiesState() instanceof MovableEntity) {
        currentLevel.addDynamicEntity((MovableEntity) careTaker.getMementoEntity(i).getEntitiesState());
      }
      if (careTaker.getMementoEntity(i).getEntitiesState() instanceof StaticEntity) {
        currentLevel.addStaticEntity(careTaker.getMementoEntity(i).getEntitiesState());
      }
    }

    //back up for current list
    for (MementoEntities entity : careTaker.getMl()) {
      originator.setEntitiesState(entity.getEntitiesState().deepClone());
      careTaker.addToMementoEntitiesMl2(originator.saveToMementoEntities());
    }
    levelTrigger = false;
  }

  @Override
  public long getLevelScore() {
    return this.score.getLevelScore();
  }


  @Override
  public Level getCurrentLevel() {
    return this.currentLevel;
  }


  @Override
  public void startLevel() {
    if (currentLevel != null) {
      // If we're restarting delete all the entities, so they're no longer rendered
      currentLevel.getEntities().forEach(Entity::delete);
      needsRefresh = true;
    }
    currentLevel = LevelBuilder.fromConfig(config).build();
    startTime = System.currentTimeMillis();
    //Used for score checking
    heroIsHere = false;
  }

  @Override
  public boolean jump() {
    if (currentLevel.getHero().jump()) {
      soundPlayer.playJumpSound();
      return true;
    }
    return false;
  }

  @Override
  public boolean moveLeft() {
    return currentLevel.getHero().moveLeft();
  }

  @Override
  public boolean moveRight() {
    return currentLevel.getHero().moveRight();
  }

  @Override
  public boolean stopMoving() {
    return currentLevel.getHero().stopMoving();
  }

  @Override
  public long getTimeSinceStart() {
    if (gameFinished) {
      return endTime - startTime;
    }

    currentTime = System.currentTimeMillis() - startTime;
    System.out.println("currentTime: "+ currentTime/1000);
    System.out.println("System current time in GameEngine:  "+ System.currentTimeMillis());
    return currentTime;
  }

  @Override
  public long getHeroHealth() {
    if (currentLevel.getHero() != null) {
      return currentLevel.getHero().getHealth();
    }
    return 0;
  }

  private void updateEntities() {
    // Collect the entities from the current level
    List<Entity> staticEntities = currentLevel.getStaticEntities();
    List<MovableEntity> dynamicEntities = currentLevel.getDynamicEntities();
    // Remove any dead entities
    staticEntities.removeIf(Entity::isDeleted);
    dynamicEntities.removeIf(Entity::isDeleted);


    // Move everything that can move
    for (MovableEntity a : dynamicEntities) {
      a.moveTick();
    }

    // Check for collisions
    for (MovableEntity a : dynamicEntities) {
      for (Entity b : currentLevel.getEntities()) {
        if (a != b && a.overlappingSameLayer(b)) {
          // Only do one collision at a time
          b.handleCollision(a);
          //Check whetehr hero and Slime is existed or not
          if(a instanceof Hero || b instanceof Hero){
            this.heroIsHere = true;
          }
          break;
        }
      }
    }
  }

  private void updateState() throws IOException {
    Hero hero = currentLevel.getHero();
    // Check if we need to change state based on the hero
    if (hero.isFinished()) {
      if (!currentLevel.getNextLevelInformPath().equals("")) {
        //Retrieve level information from currentLevel
        String levelNumber = currentLevel.getNextLevelInformPath().substring(2, 8);
        headsUpDisplayMessage = "Next Round:" + levelNumber;
        this.config = levelTransition.runNextlevel(currentLevel.getNextLevelInformPath());
        deleteAllEntities();
        startLevel();
        totalLevelScore = totalLevelScore + score.getLevelScore();
        score = new Score(this);
        System.out.println("currentLevelInformation: " + this.currentLevel.getNextLevelInformPath());

      } else {
        headsUpDisplayMessage = "GAME OVER! YOU WIN!";
        endTime = System.currentTimeMillis();
        currentLevel.getEntities().forEach(Entity::delete);
        needsRefresh = true;
        gameFinished = true;
      }
    } else if (hero.isDeleted()) {
      if(!levelTrigger){
        headsUpDisplayMessage = "YOU LOSE: TRY AGAIN!";
        heroDiedBefore = true;
        this.startLevel();
      }
    } else if (headsUpDisplayMessage != null && hero.getXVelocity() != 0) {
      headsUpDisplayMessage = null;
    }

    //Check for score
    score.checkTheScore();
  }

  @Override
  public void tick() throws IOException {
    // Don't update anything once we've completed the game
    if (gameFinished) {
      return;
    }

    updateEntities();
    updateState();


    // Make the level tick if it has anything to do
    this.currentLevel.tick();
  }

  @Override
  public boolean needsRefresh() {
    return needsRefresh;
  }

  @Override
  public void clean() {
    needsRefresh = false;
  }

  public String getHeadsUpDisplayMessage() {
    return headsUpDisplayMessage;
  }

  @Override
  public void setCurrentLevel(Level currentLevel) {
      this.currentLevel = currentLevel;
  }


  public long getTotalLevelScore() {
    return totalLevelScore;
  }

  public long getCurrentTime() {
    return currentTime;
  }

  @Override
  public boolean getHeroIsHere() {
    return this.heroIsHere;
  }

  @Override
  public void setHeroIsHere(boolean heroIsHere) {
    this.heroIsHere = heroIsHere;
  }


  public boolean isTransitionHappen(){
    return levelTransition.isTransitionHappen();
  }

  public void setTransitionHappen(boolean transitionHappen){
    levelTransition.setTransitionHappen(false);
  }

  public boolean isHeroDiedBefore() {
    return heroDiedBefore;
  }

  public void setHeroDiedBefore(boolean heroDiedBefore) {
    this.heroDiedBefore = heroDiedBefore;
  }
}
