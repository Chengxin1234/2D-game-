package stickman.model.entities.platforms;

import stickman.model.config.Position;
import stickman.model.entities.Entity;
import stickman.model.entities.StaticEntity;

public class LogPlatform extends StaticEntity {
  private static final String LOG_PATH = "/log.png";

  public LogPlatform(Position<Double> position) {
    super(position, LOG_PATH, Layer.FOREGROUND, 9, 76);
  }

  @Override
  public LogPlatform deepClone(){
//    System.out.println("HeroClone has been called! ");
    double xPOS = getXPos();
    double yPos = getYPos();
    Position<Double> position = new Position<>(xPOS,yPos);
    LogPlatform cloneEntity = new LogPlatform(position);
    return cloneEntity;
  }

}
