package stickman.model.entities.character.movementStrategies;

import stickman.model.entities.character.AbstractCharacter;

public class Stay extends MovementStrategy {

  @Override
  void internalMove(AbstractCharacter character) {
    // do nothing
  }

  @Override
  public Stay deepClone() {
    return new Stay();
  }
}
