package stickman.model.LevelTransition;

import stickman.model.config.ConfigParser;
import stickman.model.config.JsonConfigParser;

import java.io.IOException;


public class LevelTransition {
    private boolean transitionHappen = false;

    public ConfigParser runNextlevel(String nextLevelInformPath ) throws IOException {

        transitionHappen = true;
        return new JsonConfigParser(nextLevelInformPath);
    }

    public boolean isTransitionHappen() {
        return transitionHappen;
    }

    public void setTransitionHappen(boolean transitionHappen) {
        this.transitionHappen = transitionHappen;
    }
}