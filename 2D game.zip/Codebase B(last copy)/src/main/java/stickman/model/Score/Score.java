package stickman.model.Score;

import stickman.model.GameEngine;
import stickman.model.entities.character.Slime;

public class Score{

    private long LevelScore = 0;
    private long slimeScore = 0;
    private long timeScore = 0;
    private long tmp2 = 0;
    private long tmp = 0;

    private  GameEngine model;
    public Score (GameEngine model){
       this.model = model;
    }

    public void checkTheScore(){

        System.out.println("System current time in Score:  "+ System.currentTimeMillis());

        //kill the Slime
        for(int i = 0; i < model.getCurrentLevel().getEntities().size(); i++){
            if(model.getCurrentLevel().getEntities().get(i) instanceof Slime) {
                if (model.getCurrentLevel().getEntities().get(i).isDeleted() && model.getHeroIsHere()) {
                    addSlimeScore();
                    model.setHeroIsHere(false);
                }
            }
        }

        //Earn time
        if((long)(model.getCurrentLevel().getTargetTime() - model.getCurrentTime()/1000) >=0 ){
            tmp = model.getCurrentTime()/1000 ;
            if(tmp2 != tmp ){
                System.out.println("tmp outSide: "+ tmp);
                if(tmp != 0) {
                    System.out.println("tmp: " + tmp);
                    timeScore = timeScore + tmp - tmp2;
                    model.setHeroDiedBefore(false);
                }
                tmp2 = tmp;
            }
        }else {
            tmp = model.getCurrentTime()/1000 ;
            if(tmp2 != tmp  ){
                if(LevelScore > 0 && tmp != 0 ) {
                    System.out.println("tmp: " + tmp);
                    timeScore = timeScore + tmp2 -tmp;
                    model.setHeroDiedBefore(false);
                }
                tmp2 = tmp;
//                System.out.println("Current TimeScore: " + timeScore);
            }
        }

        //Transfer into second level, the timeScore will be counted down to 0
       if(model.isTransitionHappen()){
            timeScore = 0;
            model.setTransitionHappen(false);
        }
        addToTotalScore();
    }

    public void addSlimeScore(){
        slimeScore = slimeScore + 100;
    }


    public void addToTotalScore(){
        LevelScore = slimeScore + timeScore;
    }



    public long getLevelScore() {
        return LevelScore;
    }

    public void setLevelScore(long levelScore) {
        LevelScore = levelScore;
    }

    public long getSlimeScore() {
        return slimeScore;
    }

    public void setSlimeScore(long slimeScore) {
        this.slimeScore = slimeScore;
    }

    public long getTimeScore() {
        return timeScore;
    }

    public void setTimeScore(long timeScore) {
        this.timeScore = timeScore;
    }

    public long getTmp2() {
        return tmp2;
    }

    public void setTmp2(long tmp2) {
        this.tmp2 = tmp2;
    }

    public long getTmp() {
        return tmp;
    }

    public void setTmp(long tmp) {
        this.tmp = tmp;
    }
}
