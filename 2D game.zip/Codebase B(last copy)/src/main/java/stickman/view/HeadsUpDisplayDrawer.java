package stickman.view;

import javafx.scene.control.Label;
import javafx.scene.layout.Pane;
import javafx.scene.text.Font;
import stickman.model.GameEngine;

public class HeadsUpDisplayDrawer implements ForegroundDrawer {
  private static final double X_PADDING = 50;
  private static final double Y_PADDING = 5;
  private Pane pane;
  private GameEngine model;
  private Label timeElapsed = new Label();
  private Label health = new Label();
  private Label message = new Label();
  private Label leveltargetTime = new Label();
  private Label score = new Label();
  private Label totalScore = new Label();

  @Override
  public void draw(GameEngine model, Pane pane) {
    this.model = model;
    this.pane = pane;
    update();
    timeElapsed.setFont(new Font("Monospaced Regular", 20));
    health.setFont(new Font("Monospaced Regular", 20));
    message.setFont(new Font("Monospaced Regular", 50));
    //Add one TargetTime aim
    leveltargetTime.setFont(new Font("Monospaced Regular", 20));
    //Add one Score aim
    score.setFont(new Font("Monospaced Regular", 20));
    totalScore.setFont(new Font("Monospaced Regular", 20));

    this.pane.getChildren().addAll(timeElapsed, health, message,leveltargetTime,score,totalScore);
  }

  @Override
  public void update() {
    // Set the positions of the labels
    timeElapsed.setLayoutX(X_PADDING / 2);
    timeElapsed.setLayoutY(Y_PADDING);

    score.setLayoutX(timeElapsed.getLayoutX() + X_PADDING + timeElapsed.getWidth());
    score.setLayoutY(Y_PADDING);

    leveltargetTime.setLayoutX(score.getLayoutX() + X_PADDING + score.getWidth());
    leveltargetTime.setLayoutY(Y_PADDING);

    health.setLayoutX(leveltargetTime.getLayoutX() + X_PADDING + leveltargetTime.getWidth());
    health.setLayoutY(Y_PADDING);


    totalScore.setLayoutX(health.getLayoutX() + X_PADDING + health.getWidth());
    totalScore.setLayoutY(Y_PADDING);

    message.setLayoutX(pane.getWidth() / 6);
    message.setLayoutY(pane.getHeight() / 4);

    // Set the text
    score.setText(String.format("LEVELSCORE%n   %03d", model.getLevelScore()));
    timeElapsed.setText(String.format("TIME%n %03d", (model.getTimeSinceStart() / 1000)));
//    System.out.println("CurrentTime3: "+ model.getTimeSinceStart() / 1000);
    leveltargetTime.setText(String.format("TARGETTIME%n  %03d",(long)(model.getCurrentLevel().getTargetTime())));
    totalScore.setText(String.format("TOTALLEVELSCORE%n   %03d", (model.getTotalLevelScore())));
    health.setText(String.format("HEALTH%n   %03d", model.getHeroHealth()));
    message.setText(model.getHeadsUpDisplayMessage());


  }
}
